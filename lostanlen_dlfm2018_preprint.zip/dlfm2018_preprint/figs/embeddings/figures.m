transf = 'mf';
dmap_003;
print -dpng mf_tech_two_dmap.png
dmap_004;
print -dpng mf_inst_two_dmap.png

transf = 'sc';
dmap_003;
print -dpng sc_tech_two_dmap.png
dmap_004;
print -dpng sc_inst_two_dmap.png
