System: co1_feSc_me1_ne5_prLm_reMofa_sc1000_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 88.53
Technique P@5: 72.08
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 82.62
Technique P@5: 84.31
 
 
System: co1_feSc_me1_ne5_prLm_reMofa_sc25_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 88.86
Technique P@5: 66.42
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 86.54
Technique P@5: 80.03
 
 
System: co1_feSc_me1_ne5_reMofa_sc1000_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 87.03
Technique P@5: 63.42
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 80.77
Technique P@5: 78.25
 
 
System: co1_feSc_me1_ne5_reMofa_sc25_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 85.60
Technique P@5: 64.21
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 80.84
Technique P@5: 78.18
 
 
System: cu1_feMf_ne5_prLm_reMofa_sc1000_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 88.56
Technique P@5: 58.84
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 88.50
Technique P@5: 70.63
 
 
System: cu1_feMf_ne5_prLm_reMofa_sc25_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 88.56
Technique P@5: 58.84
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 88.50
Technique P@5: 70.63
 
 
System: cu1_feMf_ne5_reMofa_sc1000_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 87.34
Technique P@5: 54.93
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 87.77
Technique P@5: 67.88
 
 
System: cu1_feMf_ne5_reMofa_sc25_st1.mat
All techniques
Instrument P@5: 100.00
Sordina P@5: 87.34
Technique P@5: 54.93
 
Ordinary techniques
Instrument P@5: 100.00
Sordina P@5: 87.77
Technique P@5: 67.88